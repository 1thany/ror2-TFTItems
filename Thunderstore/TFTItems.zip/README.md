# TFT Items 

Created by **Phorg**.

---

![item chart png](icons/readMeItemChart.png)


## Asset Credits

All item icons are pulled from *League of Legends Wiki* (© Riot Games), not my own creations. 
